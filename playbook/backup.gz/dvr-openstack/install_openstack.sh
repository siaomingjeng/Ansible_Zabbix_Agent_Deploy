#!/bin/bash

#Author:chengb
#Date:2015.12.17
#
#install openstack, config the glance and cinder with ceph
#how to use it?
#(1) you must config the environ  networks and yum repos
#(2) you must config all the node's hostname . /etc/hosts and it's ip address
#(3) you must generate the glance's ceph file , cinder and computer's ceph file store them in the config dir
#(4) you must modify the openstack-common

# HOSTNAME will do something and other nodes will not
cd $(cd `dirname $0`; pwd)

. ./openstack-common

usage()
{
    echo "$0 packages_controller"
    echo "$0 packages_computer"
    echo "$0 packages_hanode"
    echo "$0 hanode HOSTNAME"
    echo "$0 ready_for_ceph CEPH_MON_IP  |create"
    echo "$0 ntp"
    echo "$0 mysql-controller"
    echo "$0 scp_cookie IP1 IP2"
    echo "$0 rabbit-controller HOSTNAME HOSTNAME1..."
    echo "$0 rabbit-ha-mode"
    echo "$0 keystone-controller HOSTNAME"
    echo "$0 glance-controller HOSTNAME"
    echo "$0 nova-controller HOSTNAME"
    echo "$0 neutron-controller HOSTNAME"
    echo "$0 dashboard-controller"
    echo "$0 cinder-controller HOSTNAME"
    echo "$0 nova-computer"
    echo "$0 neutron-computer"
    echo "$0 cinder-computer"

}


log_out()
{
    if [ $1 = 0 ] ;then
        echo "$2 success....................." >> log
    else
        echo "$2 failed please check log....." >> log
        exit 1
    fi
}

######################install packages################################
install_controller_packages()
{
    yum remove NetworkManager  -y
    pkill -9 NetworkManager
    yum install ntp -y
    log_out "$?" "yum install ntp"
    yum install openstack-selinux python-openstackclient -y
    log_out "$?" "yum install openstack-selinux python-openstackclient"
    yum install mariadb mariadb-server python2-PyMySQL -y
    log_out "$?" "yum install mariadb mariadb-server python2-PyMySQL"
    yum install rabbitmq-server -y
    log_out "$?" "yum install rabbitmq-server"
    yum install openstack-keystone httpd mod_wsgi  memcached python-memcached -y
    log_out "$?" "yum install openstack-keystone.."
    yum install openstack-glance  -y
    log_out "$?" "yum install openstack-glance "
    yum install openstack-nova-api openstack-nova-cert openstack-nova-conductor openstack-nova-console openstack-nova-novncproxy openstack-nova-scheduler -y
    log_out "$?" "yum install openstack-nova-api .."
    yum install openstack-neutron openstack-neutron-ml2 openstack-neutron-openvswitch -y
    log_out "$?" "yum install openstack-neutron .."
    yum install openstack-dashboard  -y
    log_out "$?" "yum install openstack-dashboard .."
    yum install openstack-cinder python-cinderclient python-oslo-db -y
    log_out "$?" "yum install openstack-cinder .."
    yum install python-rbd -y
    log_out "$?" "yum install python-rbd"

}

install_computer_packages()
{
    yum remove NetworkManager  -y
    pkill -9 NetworkManager
    yum install ntp -y
    log_out "$?" "yum install ntp"
    yum install openstack-selinux -y
    log_out "$?" "yum install openstack-selinux"
    yum install openstack-nova-compute -y
    log_out "$?" "openstack-nova-compute sysfsutils"
    yum install openstack-neutron openstack-neutron-ml2 openstack-neutron-openvswitch -y
    log_out "$?" "yum install openstack-neutron .."
    yum install openstack-cinder python-oslo-db python-oslo-log MySQL-python -y
    log_out "$?" "yum install openstack-cinder .."
    yum install ceph -y
    log_out "$?" "yum install ceph "
	
    ########Add inject_password, inject_key, inject_partition function for vm#############
    yum install python-libguestfs libguestfs-tools -y
    log_out "$?" "yum install python-libguestfs libguestfs-tools "

}

install_hanode_packages()
{
    yum install ntp -y
    log_out "$?" "yum install ntp"
    yum install haproxy -y
    log_out "$?" "yum install haproxy"
    yum install keepalived -y
    log_out "$?" "yum install keepalived"
}

##########################config service#############################
ready_for_ceph_conf()
{
    ######glance ceph conf################
    [ "$2" = "create" ] && {
        ssh $1 ceph osd pool create images $IMAGES_POOL 
        log_out "$?" "ceph osd pool create images $IMAGES_POOL"
        ssh $1 "ceph auth get-or-create client.glance mon 'allow r' osd 'allow class-read object_prefix rbd_children, allow rwx pool=images'"
        log_out "$?" "ceph auth get-or-create client.glance"
    }
    scp $1:/etc/ceph/ceph.conf  `pwd`/$VERSION/controller/glance/ceph
    log_out "$?" "scp $1:/etc/ceph/ceph.conf  `pwd`/$VERSION/controller/glance/ceph"
    ssh $1 ceph auth get-or-create client.glance |  tee `pwd`/$VERSION/controller/glance/ceph/ceph.client.glance.keyring
    log_out "$?" "ceph auth get-or-create client.glance"
    
    [ "$2" = "create" ] && {
        ssh $1 ceph osd pool create volumes $VOLUMES_POOL
        log_out "$?" "ceph osd pool create volumes $VOLUMES_POOL"
        ssh $1 ceph osd pool create vms $VMS_POOL
        log_out "$?" "ceph osd pool create vms $VMS_POOL"
        ssh $1 "ceph auth get-or-create client.cinder mon 'allow r' osd 'allow class-read object_prefix rbd_children, allow rwx pool=volumes, allow rwx pool=vms, allow rx pool=images'"
        log_out "$?" "ceph auth get-or-create client.cinder mon"
    }
    scp $1:/etc/ceph/ceph.conf  `pwd`/$VERSION/computer/nova/ceph
    log_out "$?" "scp $1:/etc/ceph/ceph.conf  `pwd`/$VERSION/computer/nova/ceph"
    ssh $1 ceph auth get-or-create client.cinder |  tee  `pwd`/$VERSION/computer/cinder/ceph/ceph.client.cinder.keyring
    log_out "$?" "ceph auth get-or-create client.cinder"
    ssh $1 ceph auth get-key client.cinder |  tee `pwd`/$VERSION/computer/nova/ceph/client.cinder.key
    log_out "$?" "ceph auth get-key client.cinder"
}


config_ntp()
{
    cp /usr/share/zoneinfo/Asia/Shanghai /etc/localtime
    ntpdate $NTP_SERVER_IP
    log_out "$?" "ntp time sync from server "
#    sed -i "/server $NTP_SERVER_IP iburst/d" /etc/ntp.conf
    sed -i "/server 0.centos.pool.ntp.org iburst/a\server $NTP_SERVER_IP iburst" /etc/ntp.conf
    sed -i "/server 0.centos.pool.ntp.org iburst/d" /etc/ntp.conf
    sed -i "/server 1.centos.pool.ntp.org iburst/d" /etc/ntp.conf
    sed -i "/server 2.centos.pool.ntp.org iburst/d" /etc/ntp.conf
    sed -i "/server 3.centos.pool.ntp.org iburst/d" /etc/ntp.conf
    systemctl enable ntpd.service && systemctl start ntpd.service
    log_out "$?" "systemctl start ntp.service"
}

config_mysql()
{
    echo > /etc/my.cnf.d/openstack.cnf
    cat > /etc/my.cnf.d/openstack.cnf <<EOF
[mysqld]
bind-address = $MYSQL_IP
default-storage-engine = innodb
innodb_file_per_table
collation-server = utf8_general_ci
init-connect = 'SET NAMES utf8'
character-set-server = utf8
max_connections=5000
EOF
    systemctl enable mariadb.service && systemctl start mariadb.service
    log_out "$?" "systemctl start mariadb.service"
#    sed -i '/Group=mysql/a\LimitNOFILE=65535' /usr/lib/systemd/system/mariadb.service
#    systemctl daemon-reload
#    systemctl restart mariadb.service
#init environment and set mysql password
    mysql_secure_installation <<EOF

y
$MYSQL_DBPASS
$MYSQL_DBPASS
y
y
y
y
EOF
}

clean_database_environ()
{
    for database in glance keystone neutron nova cinder ;do
        drop_db="DROP DATABASE $database"
        echo  $drop_db
        mysql -uroot -p$MYSQL_DBPASS  -e "${drop_db}"
    done
}


mysql_create_database()
{
### this will create DATABASE in mysql
## $1 database name
## $2 database password
    user=$1
    [ "$1" = "nova_api" ] && user=nova
    create_db="CREATE DATABASE $1"
    permission="GRANT ALL PRIVILEGES ON $1.* TO '$user'@'localhost' IDENTIFIED BY '$2'"
    permission2="GRANT ALL PRIVILEGES ON $1.* TO '$user'@'%' IDENTIFIED BY '$2'"
    mysql -uroot -p$MYSQL_DBPASS  -e "${create_db}"
    log_out "$?" "CREATE DATABASE $1"
    mysql -uroot -p$MYSQL_DBPASS  -e "${permission}"
    mysql -uroot -p$MYSQL_DBPASS  -e "${permission2}"
}

scp_rabbitmq_cookie()
{
    ssh $1 cat  /var/lib/rabbitmq/.erlang.cookie | tee `pwd`/$VERSION/rabbitmq/.erlang.cookie
    ssh $1 systemctl start rabbitmq-server.service
    shift 

    for host in $* ; do
        scp `pwd`/$VERSION/rabbitmq/.erlang.cookie $host:/var/lib/rabbitmq/
        log_out "$?" "scp /var/lib/rabbitmq/.erlang.cookie $host:/var/lib/rabbitmq/"
    done
}

config_rabbitmq()
{
    local my_hostname=`cat /etc/hostname`
    if [ "$my_hostname" = "$1" ]; then
        systemctl enable rabbitmq-server.service && systemctl start rabbitmq-server.service
        log_out "$?" "systemctl start rabbitmq-server.service"
        rabbitmqctl add_user openstack $RABBIT_PASS && rabbitmqctl set_permissions openstack ".*" ".*" ".*"
        log_out "$?" "rabbitmqctl set_permissions openstack"
        #systemctl stop rabbitmq-server.service

        #rabbitmqctl cluster_status

   else
        chown rabbitmq:rabbitmq /var/lib/rabbitmq/.erlang.cookie
        chmod 400 /var/lib/rabbitmq/.erlang.cookie
        systemctl enable rabbitmq-server.service &&  systemctl start rabbitmq-server.service
        rabbitmqctl cluster_status
        rabbitmqctl stop_app
        rabbitmqctl join_cluster rabbit@$1
        rabbitmqctl start_app
   fi
}

config_rabbitmq_ha()
{
    rabbitmqctl set_policy ha-all '^(?!amq\.).*' '{"ha-mode": "all"}'
}

create_user_and_check_keystone()
{
    export OS_TOKEN=$ADMIN_TOKEN
    export OS_URL=http://$CONTROLLER1_IP:35357/v3
    export OS_IDENTITY_API_VERSION=3
    openstack service create --name keystone --description "OpenStack Identity" identity
    log_out "$?" "openstack service create --name keystone --description "OpenStack Identity" identity"

    openstack endpoint create --region RegionOne identity public http://$CONTROLLER_VIP:10008/v3
    log_out "$?" "openstack endpoint create --region RegionOne identity public http://$CONTROLLER_VIP:10008/v3"
    openstack endpoint create --region RegionOne identity internal http://$CONTROLLER_VIP:10008/v3
    log_out "$?" "openstack endpoint create --region RegionOne identity internal http://$CONTROLLER_VIP:10008/v3"
    openstack endpoint create --region RegionOne identity admin http://$CONTROLLER_VIP:10006/v3
    log_out "$?" "openstack endpoint create --region RegionOne identity admin http://$CONTROLLER_VIP:10006/v3"

    openstack domain create --description "Default Domain" default
    log_out "$?" "openstack domain create --description "Default Domain" default"
    
    openstack project create --domain default --description "Admin Project" admin
    log_out "$?" "openstack project create --domain default --description "Admin Project" admin"

    openstack user create --domain default --password $ADMIN_PASS admin
    log_out "$?" "openstack user create --domain default --password $ADMIN_PASS admin"
    openstack role create admin
    log_out "$?" "openstack role create admin"
    openstack role add --project admin --user admin admin
    log_out "$?" "openstack role add --project admin --user admin admin"
    openstack project create --domain default --description "Service Project" service
    log_out "$?" "openstack project create --domain default --description "Service Project" service"
    openstack project create  --domain default --description "Demo Project" demo
    log_out "$?" "openstack project create  --domain default --description "Demo Project" demo"
    openstack user create --domain default --password $DEMO_PASS demo
    log_out "$?" "openstack user create --domain default --password $DEMO_PASS demo"
    openstack role create user
    log_out "$?" "openstack role create user"
    openstack role add --project demo --user demo user
    log_out "$?" "openstack role add --project demo --user demo user"


######check keystone ##### only check on controller1 not on vip  ##########
    unset OS_TOKEN OS_URL
  
    openstack --os-auth-url http://$CONTROLLER1_IP:35357/v3 --os-project-domain-name default --os-user-domain-name default --os-project-name admin --os-username admin --os-auth-type password --os-password $ADMIN_PASS  token issue
    log_out "$?"  "check admin keystone"
    openstack --os-auth-url http://$CONTROLLER1_IP:5000/v3 --os-project-domain-name default --os-user-domain-name default --os-project-name demo --os-username demo --os-auth-type password --os-password $DEMO_PASS token issue
    log_out "$?"  "check demo keystone"

}

create_admin_file()
{
## generate the admin file,eg. admin-openrc.sh
    echo >  `pwd`/$VERSION/admin-openrc.sh
    cat > `pwd`/$VERSION/admin-openrc.sh <<EOF
export OS_PROJECT_DOMAIN_NAME=default
export OS_USER_DOMAIN_NAME=default
export OS_PROJECT_NAME=admin
export OS_USERNAME=admin
export OS_PASSWORD=$ADMIN_PASS
export OS_AUTH_URL=http://$CONTROLLER_VIP:10006/v3
export OS_IDENTITY_API_VERSION=3
export OS_IMAGE_API_VERSION=2
EOF

}

config_keystone()
{
    local my_hostname=`cat /etc/hostname`
    systemctl enable memcached.service && systemctl start memcached.service
    log_out "$?" "systemctl start memcached.service"

    [ "$my_hostname" = "$1" ] && mysql_create_database keystone $KEYSTONE_DBPASS

    cp -f `pwd`/$VERSION/controller/keystone/keystone.conf  /etc/keystone/
    sed -i "s/ADMIN_TOKEN/$ADMIN_TOKEN/" /etc/keystone/keystone.conf
    sed -i "s/MYSQL_HOST/$MYSQL_HOST/" /etc/keystone/keystone.conf
    sed -i "s/KEYSTONE_DBPASS/$KEYSTONE_DBPASS/" /etc/keystone/keystone.conf
#    sed -i "s/MEMCACHE_SERVERS/$MEMCACHE_SERVERS/" /etc/keystone/keystone.conf

    su -s /bin/sh -c "keystone-manage db_sync" keystone
    log_out "$?" "su -s /bin/sh -c "keystone-manage db_sync" keystone"
    keystone-manage fernet_setup --keystone-user keystone --keystone-group keystone
    log_out "$?" "keystone-manage fernet_setup --keystone-user keystone --keystone-group keystone"    

    sed -i "/ServerName www.example.com:80/a\ServerName $CONTROLLER_VIP" /etc/httpd/conf/httpd.conf >/dev/null
    cp -f `pwd`/$VERSION/controller/keystone/wsgi-keystone.conf   /etc/httpd/conf.d/
    #mkdir -p /var/www/cgi-bin/keystone
    #cp -f `pwd`/$VERSION/controller/keystone/admin   /var/www/cgi-bin/keystone
    #cp -f `pwd`/$VERSION/controller/keystone/main    /var/www/cgi-bin/keystone
    #chown -R keystone:keystone /var/www/cgi-bin/keystone
    #chmod 755 /var/www/cgi-bin/keystone/*
    systemctl enable httpd.service && systemctl start httpd.service
    log_out "$?" "systemctl start httpd.service"

    [ "$my_hostname" = "$1" ] && create_user_and_check_keystone
    create_admin_file
}

config_glance()
{
    local my_hostname=`cat /etc/hostname`
    [ "$my_hostname" = "$1" ] && mysql_create_database glance $GLANCE_DBPASS
    source `pwd`/$VERSION/admin-openrc.sh
    [ "$my_hostname" = "$1" ] && {
        openstack user create --domain default --password $GLANCE_PASS glance
        log_out "$?" "openstack user create --domain default --password $GLANCE_PASS glance"
        openstack role add --project service --user glance admin
        log_out "$?" "openstack role add --project service --user glance admin"
        openstack service create --name glance --description "OpenStack Image service" image
        log_out "$?" "openstack service create --name glance --description "OpenStack Image service" image"

        openstack endpoint create --region RegionOne image public http://$CONTROLLER_VIP:10002
        log_out "$?" "openstack endpoint create --region RegionOne image public"
        openstack endpoint create --region RegionOne image internal http://$CONTROLLER_VIP:10002
        log_out "$?" "openstack endpoint create --region RegionOne image internal"
        openstack endpoint create --region RegionOne image admin http://$CONTROLLER_VIP:10002
        log_out "$?" "openstack endpoint create --region RegionOne image admin"
    }

### modify the glance-api.conf and glance-registry.conf
    mkdir -p  /etc/ceph
    cp -f  `pwd`/$VERSION/controller/glance/ceph/*  /etc/ceph
    chown glance:glance /etc/ceph/ceph.client.glance.keyring

    cp -f  `pwd`/$VERSION/controller/glance/glance-api.conf  /etc/glance/
    cp -f  `pwd`/$VERSION/controller/glance/glance-registry.conf  /etc/glance/
    cp -f  `pwd`/$VERSION/controller/glance/ceph/*  /etc/ceph/
    chown glance:glance /etc/ceph/ceph.client.glance.keyring
    sed -i "s/GLANCE_DBPASS/$GLANCE_DBPASS/"         /etc/glance/glance-api.conf
    sed -i "s/MYSQL_HOST/$MYSQL_HOST/"               /etc/glance/glance-api.conf
    sed -i "s/CONTROLLER_VIP/$CONTROLLER_VIP/"       /etc/glance/glance-api.conf
    sed -i "s/GLANCE_PASS/$GLANCE_PASS/"             /etc/glance/glance-api.conf
    sed -i "s/MEMCACHE_SERVERS/$MEMCACHE_SERVERS/"   /etc/glance/glance-api.conf
    sed -i "s/GLANCE_DBPASS/$GLANCE_DBPASS/"         /etc/glance/glance-registry.conf
    sed -i "s/MYSQL_HOST/$MYSQL_HOST/"               /etc/glance/glance-registry.conf
    sed -i "s/CONTROLLER_VIP/$CONTROLLER_VIP/"       /etc/glance/glance-registry.conf
    sed -i "s/GLANCE_PASS/$GLANCE_PASS/"             /etc/glance/glance-registry.conf
    sed -i "s/MEMCACHE_SERVERS/$MEMCACHE_SERVERS/"   /etc/glance/glance-registry.conf

    su -s /bin/sh -c "glance-manage db_sync" glance
    log_out "$?" "su -s /bin/sh -c "glance-manage db_sync" glance"

    systemctl enable openstack-glance-api.service openstack-glance-registry.service && \
    systemctl start openstack-glance-api.service openstack-glance-registry.service
    log_out "$?" "systemctl start openstack-glance-api.service openstack-glance-registry.service"
}

config_controller_nova()
{
    local my_hostname=`cat /etc/hostname`
    local my_ip=`ip addr show $MGMT_INTERFACE| grep -Po '(?<=inet ).*(?=\/)'| head -1`
     
    [ "$my_ip" = "" ] && log_out "1" "my_ip found"

    [ "$my_hostname" = "$1" ] &&  mysql_create_database nova $NOVA_DBPASS
    [ "$my_hostname" = "$1" ] &&  mysql_create_database nova_api $NOVA_DBPASS
    source `pwd`/$VERSION/admin-openrc.sh
    [ "$my_hostname" = "$1" ] && {
        openstack user create --domain default --password $NOVA_PASS nova
        log_out "$?" "openstack user create --domain default --password $NOVA_PASS nova"
        openstack role add --project service --user nova admin
        log_out "$?" "openstack role add --project service --user nova admin"
        openstack service create --name nova --description "OpenStack Compute" compute
        log_out "$?" "openstack service create --name nova --description "OpenStack Compute" compute"
        openstack endpoint create --region RegionOne compute public http://$CONTROLLER_VIP:10010/v2.1/%\(tenant_id\)s
        log_out "$?" "openstack endpoint create --region RegionOne compute public http://$CONTROLLER_VIP:10010/v2.1/%\(tenant_id\)s"
        openstack endpoint create --region RegionOne compute internal http://$CONTROLLER_VIP:10010/v2.1/%\(tenant_id\)s
        log_out "$?" "openstack endpoint create --region RegionOne compute internal http://$CONTROLLER_VIP:10010/v2.1/%\(tenant_id\)s"
        openstack endpoint create --region RegionOne compute admin http://$CONTROLLER_VIP:10010/v2.1/%\(tenant_id\)s
        log_out "$?" "openstack endpoint create --region RegionOne compute admin http://$CONTROLLER_VIP:10010/v2.1/%\(tenant_id\)s"
    }
    cp -f  `pwd`/$VERSION/controller/nova/nova.conf /etc/nova/
    sed -i "s/NOVA_DBPASS/$NOVA_DBPASS/" /etc/nova/nova.conf
    sed -i "s/MYSQL_HOST/$MYSQL_HOST/" /etc/nova/nova.conf
    sed -i "s/NOVA_PASS/$NOVA_PASS/"     /etc/nova/nova.conf
    sed -i "s/CONTROLLER_VIP/$CONTROLLER_VIP/"   /etc/nova/nova.conf
    sed -i "s/NEUTRON_PASS/$NEUTRON_PASS/"    /etc/nova/nova.conf
    sed -i "s/MY_IP/$my_ip/"             /etc/nova/nova.conf
    sed -i "s/RABBIT_PASS/$RABBIT_PASS/" /etc/nova/nova.conf
    sed -i "s/RABBIT_HOSTS/$RABBIT_HOSTS/" /etc/nova/nova.conf
    sed -i "s/METADATA_SECRET/$METADATA_SECRET/" /etc/nova/nova.conf
    sed -i "s/MEMCACHE_SERVERS/$MEMCACHE_SERVERS/" /etc/nova/nova.conf

    su -s /bin/sh -c "nova-manage db sync" nova
    log_out "$?" "su -s /bin/sh -c "nova-manage db sync" nova"
    su -s /bin/sh -c "nova-manage api_db sync" nova
    log_out "$?" "su -s /bin/sh -c "nova-manage api_db sync" nova"

    systemctl enable openstack-nova-api.service openstack-nova-cert.service openstack-nova-consoleauth.service openstack-nova-scheduler.service openstack-nova-conductor.service openstack-nova-novncproxy.service

    systemctl restart openstack-nova-api.service openstack-nova-cert.service openstack-nova-consoleauth.service openstack-nova-scheduler.service openstack-nova-conductor.service openstack-nova-novncproxy.service
    log_out "$?" "systemctl start nova service"

}

config_controller_neutron()
{
### neutron database create and keystone user
    local my_hostname=`cat /etc/hostname`
    local local_ip=`ip addr show $TUNNEL_INTERFACE | grep -Po '(?<=inet ).*(?=\/)'`
    [ "$local_ip" = "" ] && log_out "1" "local_ip found"
    [ "$my_hostname" = "$1" ] && mysql_create_database neutron $NEUTRON_DBPASS
    source `pwd`/$VERSION/admin-openrc.sh
    [ "$my_hostname" = "$1" ] &&{
        openstack user create --domain default --password $NEUTRON_PASS neutron
        log_out "$?" "openstack user create --password $NEUTRON_PASS neutron"
        openstack role add --project service --user neutron admin
        log_out "$?" "openstack role add --project service --user neutron admin"
        openstack service create --name neutron --description "OpenStack Networking" network
        log_out "$?" "openstack service create --name neutron --description "OpenStack Networking" network"
        openstack endpoint create --region RegionOne network public http://$CONTROLLER_VIP:10018
        log_out "$?" "openstack endpoint create --region RegionOne network public http://$CONTROLLER_VIP:10018"
        openstack endpoint create --region RegionOne network internal http://$CONTROLLER_VIP:10018
        log_out "$?" "openstack endpoint create --region RegionOne network internal http://$CONTROLLER_VIP:10018"
        openstack endpoint create --region RegionOne network admin http://$CONTROLLER_VIP:10018
        log_out "$?" "openstack endpoint create --region RegionOne network admin http://$CONTROLLER_VIP:10018"

    }

### modify the neutron.conf in controller node
    cp -f `pwd`/$VERSION/controller/neutron/neutron.conf /etc/neutron/
    cp -f `pwd`/$VERSION/controller/neutron/plugin.ini /etc/neutron/plugins/ml2/ml2_conf.ini
    cp -f `pwd`/$VERSION/controller/neutron/openvswitch_agent.ini /etc/neutron/plugins/ml2/openvswitch_agent.ini
    cp -f `pwd`/$VERSION/controller/neutron/l3_agent.ini /etc/neutron/
    cp -f `pwd`/$VERSION/controller/neutron/dhcp_agent.ini /etc/neutron/
    cp -f `pwd`/$VERSION/controller/neutron/dnsmasq-neutron.conf /etc/neutron/
    cp -f `pwd`/$VERSION/controller/neutron/metadata_agent.ini /etc/neutron/

    sed -i "s/NEUTRON_DBPASS/$NEUTRON_DBPASS/" /etc/neutron/neutron.conf
    sed -i "s/NEUTRON_PASS/$NEUTRON_PASS/"     /etc/neutron/neutron.conf
    sed -i "s/MYSQL_HOST/$MYSQL_HOST/"         /etc/neutron/neutron.conf
    sed -i "s/CONTROLLER_VIP/$CONTROLLER_VIP/" /etc/neutron/neutron.conf
    sed -i "s/NOVA_PASS/$NOVA_PASS/"           /etc/neutron/neutron.conf
    sed -i "s/RABBIT_PASS/$RABBIT_PASS/"       /etc/neutron/neutron.conf
    sed -i "s/RABBIT_HOSTS/$RABBIT_HOSTS/"     /etc/neutron/neutron.conf

    sed -i "s/LOCAL_IP/$local_ip/"                   /etc/neutron/plugins/ml2/openvswitch_agent.ini
    sed -i "s/CONTROLLER_VIP/$CONTROLLER_VIP/"       /etc/neutron/metadata_agent.ini
#    sed -i "s/NEUTRON_PASS/$NEUTRON_PASS/"           /etc/neutron/metadata_agent.ini
    sed -i "s/METADATA_SECRET/$METADATA_SECRET/"     /etc/neutron/metadata_agent.ini
    sed -i "s/MEMCACHE_SERVERS/$MEMCACHE_SERVERS/"   /etc/neutron/neutron.conf

    ln -s /etc/neutron/plugins/ml2/ml2_conf.ini /etc/neutron/plugin.ini
    su -s /bin/sh -c "neutron-db-manage --config-file /etc/neutron/neutron.conf  --config-file /etc/neutron/plugins/ml2/ml2_conf.ini upgrade head" neutron
    log_out "$?" "su -s /bin/sh -c neutron-db-manage"
    cat >> /etc/sysctl.conf << EOF
net.ipv4.ip_forward = 1
net.ipv4.conf.all.rp_filter = 0
net.ipv4.conf.default.rp_filter = 0
EOF
    sysctl -p
    systemctl restart openstack-nova-api.service openstack-nova-scheduler.service openstack-nova-conductor.service

    systemctl enable neutron-server.service && systemctl restart neutron-server.service
    log_out "$?" "systemctl restart neutron-server.service"

    pkill dnsmasq

    systemctl enable openvswitch.service && systemctl start openvswitch.service
    log_out "$?" "systemctl start openvswitch.service"
    ovs-vsctl add-br br-ex
    ovs-vsctl add-port br-ex $PUBLIC_INTERFACE
    ethtool -K $PUBLIC_INTERFACE gro off

#    cp /usr/lib/systemd/system/neutron-openvswitch-agent.service \
#        /usr/lib/systemd/system/neutron-openvswitch-agent.service.orig
#    sed -i 's,plugins/openvswitch/ovs_neutron_plugin.ini,plugin.ini,g' \
#        /usr/lib/systemd/system/neutron-openvswitch-agent.service

    systemctl enable neutron-openvswitch-agent.service neutron-l3-agent.service neutron-dhcp-agent.service neutron-metadata-agent.service neutron-ovs-cleanup.service

    systemctl start neutron-openvswitch-agent.service neutron-l3-agent.service neutron-dhcp-agent.service neutron-metadata-agent.service
    log_out "$?" "systemctl start neutron-openvswitch-agent.service neutron-l3-agent.service neutron-dhcp-agent.service neutron-metadata-agent.service"

}


config_dashboard()
{
    cp -f  `pwd`/$VERSION/controller/dashboard/local_settings /etc/openstack-dashboard/
    sed -i "s/CONTROLLER_VIP/$CONTROLLER_VIP/" /etc/openstack-dashboard/local_settings
    sed -i "s/MEMCAHCE_SERVERS/$DASHBOARD_MEMCACHES/" /etc/openstack-dashboard/local_settings
    setsebool -P httpd_can_network_connect on
    chown -R apache:apache /usr/share/openstack-dashboard/static
    systemctl enable httpd.service memcached.service && systemctl restart httpd.service memcached.service
    log_out "$?" "systemctl restart httpd.service memcached.service"
}

config_cinder()
{
    local my_hostname=`cat /etc/hostname`
    local my_ip=`ip addr show $MGMT_INTERFACE| grep -Po '(?<=inet ).*(?=\/)'|head -1`
    [ $my_ip = "" ] && log_out "1" "my_ip found"
    [ "$my_hostname" = "$1" ] && mysql_create_database cinder $CINDER_DBPASS
    source `pwd`/$VERSION/admin-openrc.sh
    [ "$my_hostname" = "$1" ] && {
        openstack user create --domain default --password $CINDER_PASS cinder
        log_out "$?" "openstack user create --password $CINDER_PASS cinder"
        openstack role add --project service --user cinder admin
        log_out "$?" "openstack role add --project service --user cinder admin"
        openstack service create --name cinder \
            --description "OpenStack Block Storage" volume
        log_out "$?" "openstack service create volume"
        openstack service create --name cinderv2 \
            --description "OpenStack Block Storage" volumev2
        log_out "$?" "openstack service create volumev2"
        
        openstack endpoint create --region RegionOne volume public http://$CONTROLLER_VIP:10014/v1/%\(tenant_id\)s
        log_out "$?" "openstack endpoint create --region RegionOne volume public http://$CONTROLLER_VIP:10014/v1/%\(tenant_id\)s"
        openstack endpoint create --region RegionOne volume internal http://$CONTROLLER_VIP:10014/v1/%\(tenant_id\)s
        log_out "$?" "openstack endpoint create --region RegionOne volume internal http://$CONTROLLER_VIP:10014/v1/%\(tenant_id\)s"
        openstack endpoint create --region RegionOne volume admin http://$CONTROLLER_VIP:10014/v1/%\(tenant_id\)s        
        log_out "$?" "openstack endpoint create --region RegionOne volume admin http://$CONTROLLER_VIP:10014/v1/%\(tenant_id\)s"
        
        openstack endpoint create --region RegionOne volumev2 public http://$CONTROLLER_VIP:10014/v2/%\(tenant_id\)s
        log_out "$?" "openstack endpoint create --region RegionOne volumev2 public http://$CONTROLLER_VIP:10014/v2/%\(tenant_id\)s"
        openstack endpoint create --region RegionOne volumev2 internal http://$CONTROLLER_VIP:10014/v2/%\(tenant_id\)s
        log_out "$?" "openstack endpoint create --region RegionOne volumev2 internal http://$CONTROLLER_VIP:10014/v2/%\(tenant_id\)s"
        openstack endpoint create --region RegionOne volumev2 admin http://$CONTROLLER_VIP:10014/v2/%\(tenant_id\)s
        log_out "$?" "openstack endpoint create --region RegionOne volumev2 admin http://$CONTROLLER_VIP:10014/v2/%\(tenant_id\)s"
    }
    cp -f  `pwd`/$VERSION/controller/cinder/cinder.conf /etc/cinder

    sed -i "s/MYSQL_HOST/$MYSQL_HOST/"            /etc/cinder/cinder.conf
    sed -i "s/CONTROLLER_VIP/$CONTROLLER_VIP/"    /etc/cinder/cinder.conf
    sed -i "s/CINDER_PASS/$CINDER_PASS/"          /etc/cinder/cinder.conf
    sed -i "s/CINDER_DBPASS/$CINDER_DBPASS/"        /etc/cinder/cinder.conf
    sed -i "s/RABBIT_PASS/$RABBIT_PASS/"           /etc/cinder/cinder.conf
    sed -i "s/RABBIT_HOSTS/$RABBIT_HOSTS/"        /etc/cinder/cinder.conf
    sed -i "s/MY_IP/$my_ip/"                      /etc/cinder/cinder.conf
    sed -i "s/MEMCACHE_SERVERS/$MEMCACHE_SERVERS/" /etc/cinder/cinder.conf

    chown -R cinder:cinder /etc/cinder/cinder.conf

    su -s /bin/sh -c "cinder-manage db sync" cinder
    log_out "$?" "su -s /bin/sh -c "cinder-manage db sync" cinder"

    systemctl enable openstack-cinder-api.service openstack-cinder-scheduler.service
    systemctl start openstack-cinder-api.service openstack-cinder-scheduler.service
    log_out "$?" "systemctl start openstack-cinder-api.service openstack-cinder-scheduler.service"

}

##########################config computer##################################
config_computer_nova()
{
    local my_ip=`ip addr show $MGMT_INTERFACE| grep -Po '(?<=inet ).*(?=\/)'`
    [ $my_ip = "" ] && log_out "1" "my_ip found"

    cp -f `pwd`/$VERSION/computer/cinder/ceph/* /etc/ceph
    cp -f `pwd`/$VERSION/computer/nova/ceph/ceph.conf /etc/ceph
    chown cinder:cinder /etc/ceph/ceph.client.cinder.keyring
    cp -f  `pwd`/$VERSION/computer/nova/nova.conf /etc/nova/nova.conf

    sed -i "s/MY_IP/$my_ip/"                    /etc/nova/nova.conf
    sed -i "s/CONTROLLER_VIP/$CONTROLLER_VIP/"  /etc/nova/nova.conf
    sed -i "s/VNC_VIP/$VNC_VIP/"                /etc/nova/nova.conf
    sed -i "s/NOVA_PASS/$NOVA_PASS/"            /etc/nova/nova.conf
    sed -i "s/NEUTRON_PASS/$NEUTRON_PASS/"      /etc/nova/nova.conf
    sed -i "s/SECRET_UUID/$SECRET_UUID/"        /etc/nova/nova.conf
    sed -i "s/RABBIT_PASS/$RABBIT_PASS/"        /etc/nova/nova.conf
    sed -i "s/RABBIT_HOSTS/$RABBIT_HOSTS/"      /etc/nova/nova.conf
    sed -i "s/MEMCACHE_SERVERS/$MEMCACHE_SERVERS/" /etc/nova/nova.conf
    systemctl enable libvirtd.service openstack-nova-compute.service && systemctl start libvirtd.service openstack-nova-compute.service
    log_out "$?" "systemctl start libvirtd.service openstack-nova-compute.service"
    cd `pwd`/$VERSION/computer/nova/ceph
    cat >> ceph.conf <<EOF
[client]
    rbd cache = true
    rbd cache writethrough until flush = false
    cache size =  67108864
    rbd cache max dirty = 0
    rbd cache max dirty age = 0

    admin socket = /var/run/ceph/guests/\$cluster-\$type.\$id.\$pid.\$cctid.asok
    log file = /var/log/qemu/qemu-guest-\$pid.log
    rbd concurrent management ops = 20
EOF
    cp secret  secret.xml
    sed -i "s/UUID/$SECRET_UUID/" secret.xml
    virsh secret-define --file secret.xml
    log_out "$?" "virsh secret-define --file secret.xml"
    virsh secret-set-value --secret $SECRET_UUID --base64 $(cat client.cinder.key)
    log_out "$?" "virsh secret-set-value --secret $SECRET_UUID"
    mkdir -p /var/run/ceph/guests/ /var/log/qemu/
    chown qemu:qemu /var/run/ceph/guests /var/log/qemu/

}

config_computer_neutron()
{
    local local_ip=`ip addr show $TUNNEL_INTERFACE | grep -Po '(?<=inet ).*(?=\/)'`
    [ "$local_ip" = "" ] && log_out "1" "local_ip found"
    
    cat >> /etc/sysctl.conf << EOF
net.ipv4.conf.all.rp_filter = 0
net.ipv4.conf.default.rp_filter = 0
net.bridge.bridge-nf-call-iptables = 1
net.bridge.bridge-nf-call-ip6tables = 1

net.ipv4.ip_forward = 1
net.ipv4.conf.all.rp_filter = 0
net.ipv4.conf.default.rp_filter = 0
EOF
    sysctl -p

    systemctl enable openvswitch.service && systemctl start openvswitch.service
    log_out "$?" "systemctl start openvswitch.service"
    ovs-vsctl add-br br-ex
    ovs-vsctl add-port br-ex $PUBLIC_INTERFACE
    ethtool -K $PUBLIC_INTERFACE gro off

    cp -f `pwd`/$VERSION/computer/neutron/neutron.conf /etc/neutron/
#    cp -f `pwd`/$VERSION/computer/neutron/plugin.ini /etc/neutron/plugins/ml2/ml2_conf.ini
    cp -f `pwd`/$VERSION/computer/neutron/openvswitch_agent.ini /etc/neutron/plugins/ml2/openvswitch_agent.ini
    cp -f `pwd`/$VERSION/computer/neutron/l3_agent.ini /etc/neutron/
    cp -f `pwd`/$VERSION/computer/neutron/metadata_agent.ini /etc/neutron/

    sed -i "s/NEUTRON_PASS/$NEUTRON_PASS/"     /etc/neutron/neutron.conf
    sed -i "s/CONTROLLER_VIP/$CONTROLLER_VIP/"    /etc/neutron/neutron.conf
    sed -i "s/RABBIT_PASS/$RABBIT_PASS/"       /etc/neutron/neutron.conf
    sed -i "s/RABBIT_HOSTS/$RABBIT_HOSTS/"       /etc/neutron/neutron.conf
    sed -i "s/MEMCACHE_SERVERS/$MEMCACHE_SERVERS/" /etc/neutron/neutron.conf
    sed -i "s/LOCAL_IP/$local_ip/"       /etc/neutron/plugins/ml2/openvswitch_agent.ini
    sed -i "s/CONTROLLER_VIP/$CONTROLLER_VIP/"       /etc/neutron/metadata_agent.ini
#    sed -i "s/NEUTRON_PASS/$NEUTRON_PASS/"     /etc/neutron/metadata_agent.ini
    sed -i "s/METADATA_SECRET/$METADATA_SECRET/" /etc/neutron/metadata_agent.ini
    chown -R neutron:neutron /var/lib/neutron/tmp
#    ln -s /etc/neutron/plugins/ml2/ml2_conf.ini /etc/neutron/plugin.ini

#    cp /usr/lib/systemd/system/neutron-openvswitch-agent.service /usr/lib/systemd/system/neutron-openvswitch-agent.service.orig

#    sed -i 's,plugins/openvswitch/ovs_neutron_plugin.ini,plugin.ini,g' \
#        /usr/lib/systemd/system/neutron-openvswitch-agent.service

    setenforce 0
    systemctl restart openstack-nova-compute.service
    log_out "$?" "systemctl restart openstack-nova-compute.service"
    systemctl enable neutron-openvswitch-agent.service neutron-l3-agent.service  neutron-metadata-agent.service neutron-ovs-cleanup.service

    systemctl start neutron-openvswitch-agent.service neutron-l3-agent.service neutron-metadata-agent.service
    log_out "$?" "systemctl start neutron-openvswitch-agent.service neutron-l3-agent.service neutron-metadata-agent.service"
}

config_storage_cinder()
{
    local my_ip=`ip addr show $MGMT_INTERFACE| grep -Po '(?<=inet ).*(?=\/)'| head -1`
    
    [ $my_ip = "" ] && log_out "1" "my_ip found"

    cp -f `pwd`/$VERSION/computer/cinder/ceph/* /etc/ceph
    chown cinder:cinder /etc/ceph/ceph.client.cinder.keyring
    cp -f `pwd`/$VERSION/computer/cinder/cinder.conf /etc/cinder
    sed -i "s/MYSQL_HOST/$MYSQL_HOST/"             /etc/cinder/cinder.conf
    sed -i "s/CONTROLLER_VIP/$CONTROLLER_VIP/"     /etc/cinder/cinder.conf
    sed -i "s/CINDER_PASS/$CINDER_PASS/"           /etc/cinder/cinder.conf
    sed -i "s/CINDER_DBPASS/$CINDER_DBPASS/"       /etc/cinder/cinder.conf
    sed -i "s/RABBIT_PASS/$RABBIT_PASS/"           /etc/cinder/cinder.conf
    sed -i "s/RABBIT_HOSTS/$RABBIT_HOSTS/"         /etc/cinder/cinder.conf
    sed -i "s/MY_IP/$my_ip/"                       /etc/cinder/cinder.conf
    sed -i "s/SECRET_UUID/$SECRET_UUID/"           /etc/cinder/cinder.conf
    sed -i "s/MEMCACHE_SERVERS/$MEMCACHE_SERVERS/" /etc/cinder/cinder.conf
    mkdir  -p /var/lock/cinder

    chown cinder:cinder /var/lock/cinder

    systemctl enable openstack-cinder-volume.service && systemctl start openstack-cinder-volume.service
    log_out "$?" " systemctl start openstack-cinder-volume.service"
    systemctl restart openstack-nova-compute
    log_out "$?" "systemctl restart openstack-nova-compute"
}

config_hanode()
{
    local my_hostname=`cat /etc/hostname`
    cp -f `pwd`/$VERSION/hanode/haproxy/haproxy.cfg  /etc/haproxy
    sed -i "s/CONTROLLER_VIP/$CONTROLLER_VIP/"  /etc/haproxy/haproxy.cfg
    sed -i "s/CONTROLLER1/$CONTROLLER1_IP/"  /etc/haproxy/haproxy.cfg
    sed -i "s/CONTROLLER2/$CONTROLLER2_IP/"  /etc/haproxy/haproxy.cfg

    cp -f `pwd`/$VERSION/hanode/keepalived/* /etc/keepalived/
    sed -i "s/CONTROLLER_VIP/$CONTROLLER_VIP/" /etc/keepalived/keepalived.conf
    sed -i "s/VIP_NIC/$VIP_NIC/" /etc/keepalived/keepalived.conf
    chmod 777 /etc/keepalived/check_haproxy.sh
    [ "$my_hostname" = "$1" ] && {
        sed -i 's/BACKUP/MASTER/' /etc/keepalived/keepalived.conf
        sed -i 's/priority 100/priority 90/' /etc/keepalived/keepalived.conf
    }   

    sed -i 's/SELINUX=enforcing/SELINUX=disabled/' /etc/selinux/config 
    echo "net.ipv4.ip_nonlocal_bind = 1" >> /etc/sysctl.conf
    sysctl -p
    setenforce 0
    systemctl enable haproxy
    systemctl enable keepalived.service && systemctl start keepalived.service
    log_out "$?" "systemctl start keepalived.service " 
}

case $1 in
packages_controller)
    install_controller_packages    
    ;;
packages_computer)
    install_computer_packages 
    ;;
packages_hanode)
    install_hanode_packages 
    ;;
ready_for_ceph)
    shift
    [ $# -ne 2 ] && {
        echo usage
        exit 1
    }
    ready_for_ceph_conf $1 $2
    ;;
scp_cookie)
    shift
    scp_rabbitmq_cookie $*
    ;;
hanode)
    shift
    [ $# -ne 1 ] && log_out "1" "config_hanode $*"
    config_hanode $1 
    ;;
ntp)
    config_ntp
    ;;
mysql-controller)
    config_mysql 
    ;;
rabbit-controller)
    shift
    ### rabbit1 rabbit2 rabbit3
    [ $# -lt 1 ] && log_out "1" "config_rabbitmq $*"
    config_rabbitmq $* 
    ;;
rabbit-ha-mode)
    config_rabbitmq_ha    
    ;;
keystone-controller)
    shift
    ### keystone
    [ $# -ne 1 ] && log_out "1" "config_keystone $*"
    config_keystone $*
    ;;
glance-controller)
    shift
    ### glance
    [ $# -ne 1 ] && log_out "1" "config_glance $*"
    config_glance $*
    ;;
nova-controller)
    shift
    ### nova
    [ $# -ne 1 ] && log_out "1" "config_nova $*"
    config_controller_nova $*
    ;;
neutron-controller)
    shift
    [ $# -ne 1 ] && log_out "1" "config_neutron $*"
    config_controller_neutron $*
    ;;

dashboard-controller)
    config_dashboard
    ;;
cinder-controller)
    shift
    [ $# -ne 1 ] && log_out "1" "config_cinder $*"
    config_cinder $*
    ;;
nova-computer)
    config_computer_nova
    ;;
neutron-computer)
    config_computer_neutron
    ;;
cinder-computer)
    config_storage_cinder
    ;;
*)
    usage
    ;;

esac


